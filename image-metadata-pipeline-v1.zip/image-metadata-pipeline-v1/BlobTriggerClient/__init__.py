import logging
import azure.functions as func
import azure.durable_functions as df

async def main(blob: func.InputStream, starter: str):
    client = df.DurableOrchestrationClient(starter)
    image_info = {
        "blob_name": blob.name,
        "blob_url": blob.uri
    }
    instance_id = await client.start_new("OrchestratorFunction", None, image_info)
    logging.info(f"Started orchestration with ID = '{instance_id}'.")
