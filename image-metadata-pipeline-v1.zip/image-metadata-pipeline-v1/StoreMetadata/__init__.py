import logging
import os
import pyodbc

def main(metadata: dict) -> None:
    try:
        conn_str = os.getenv("SQL_CONNECTION_STRING")
        with pyodbc.connect(conn_str) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO ImageMetadata (FileName, FileSizeKB, Width, Height, Format)
                VALUES (?, ?, ?, ?, ?)
            """, metadata["FileName"], metadata["FileSizeKB"],
                 metadata["Width"], metadata["Height"], metadata["Format"])
            conn.commit()

        logging.info(f"Metadata inserted into SQL DB: {metadata}")
    except Exception as e:
        logging.error(f"Error inserting metadata: {str(e)}")
        raise
