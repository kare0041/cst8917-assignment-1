import logging
import os
import pyodbc # Import pyodbc

# This activity function stores the image metadata into an Azure SQL Database
# using a direct pyodbc connection (for local compatibility).
def main(metadata: dict) -> str:
    logging.info(f"StoreMetadata activity function started with metadata: {metadata}")

    try:
        # Get the connection string from environment variables (local.settings.json)
        # Note: We are using "SqlConnectionString" as the key, matching the binding expectation
        # even though we're using pyodbc directly. This keeps local.settings.json consistent.
        conn_str = os.getenv("SqlConnectionString")
        if not conn_str:
            raise ValueError("SqlConnectionString environment variable is not set.")

        # Establish connection using pyodbc
        # Ensure you have the ODBC Driver 18 for SQL Server installed on your system.
        # For macOS: brew install msodbcsql18 mssql-tools
        # For Linux: Refer to Microsoft's documentation for your distro.
        with pyodbc.connect(conn_str) as conn:
            cursor = conn.cursor()

            # Prepare the INSERT statement.
            # Ensure column names match your SQL table and the keys in the metadata dictionary.
            # We are using 'ImageFormat' as returned by the ExtractMetadata function.
            insert_query = """
                INSERT INTO ImageMetadata (FileName, FileSizeKB, Width, Height, ImageFormat)
                VALUES (?, ?, ?, ?, ?)
            """
            cursor.execute(
                insert_query,
                metadata["FileName"],
                metadata["FileSizeKB"],
                metadata["Width"],
                metadata["Height"],
                metadata["ImageFormat"] # Use 'ImageFormat' as extracted
            )
            conn.commit()

        logging.info(f"Metadata successfully inserted into SQL DB via pyodbc: {metadata}")
        return "Metadata stored successfully via pyodbc."

    except pyodbc.Error as e:
        sql_state = e.args[0]
        logging.error(f"SQL Error in StoreMetadata: {sql_state}. Details: {e}")
        raise # Re-raise the exception to propagate to the orchestrator
    except Exception as e:
        logging.error(f"An unexpected error occurred in StoreMetadata: {e}")
        raise # Re-raise the exception to propagate to the orchestrator
