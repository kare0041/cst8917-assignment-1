import logging
import requests
from PIL import Image
from io import BytesIO

def main(image_info: dict) -> dict:
    try:
        response = requests.get(image_info["blob_url"])
        image = Image.open(BytesIO(response.content))

        metadata = {
            "FileName": image_info["blob_name"].split("/")[-1],
            "FileSizeKB": round(len(response.content) / 1024, 2),
            "Width": image.width,
            "Height": image.height,
            "Format": image.format
        }

        logging.info(f"Extracted metadata: {metadata}")
        return metadata
    except Exception as e:
        logging.error(f"Error extracting metadata: {str(e)}")
        raise
